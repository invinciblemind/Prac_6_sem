"""Client program."""

import sys
import socket
import shlex
import threading
import readline
import time
import webbrowser
from pathlib import Path


def open_documentation():
    """Open generated HTML documentation in browser."""
    # Look for docs inside installed package: mood/html/index.html
    base_dir = Path(__file__).parent.parent  # mood/
    docs_path = base_dir / 'html' / 'index.html'
    if docs_path.exists():
        webbrowser.open(f'file://{docs_path.resolve()}')
    else:
        print("Documentation not found. Please reinstall the package.")


def receive_messages(s):
    """Receive all messages."""
    while True:
        try:
            reply = s.recv(1024).rstrip().decode()
            print(f'\n{reply}\n{readline.get_line_buffer()}', end="", flush=True)
        except:
            break

def start_client():
    username = sys.argv[1]
    host = "localhost"
    port = 1337

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))

        s.sendall((username + '\n').encode())

        response = s.recv(1024).decode().strip()
        if response == "DENIED":
            print("Username already taken")
            sys.exit(1)
        print(response)

        receive_thread = threading.Thread(target=receive_messages, args=(s,), daemon=True)
        receive_thread.start()
        # while msg := sys.stdin.buffer.readline():
        while True:
            time.sleep(0.01)
            try:
                # cmd = shlex.split(msg.decode())
                msg = input()
                cmd = shlex.split(msg)
                # Local commands (not sent to server)
                if cmd[0] == 'documentation':
                    open_documentation()
                    continue
                # Server commands
                if len(cmd) == 1 and len(cmd[0]) <= 5:
                    if cmd[0] == 'up':
                        s.sendall('move 0 -1\n'.encode())
                    elif cmd[0] == 'down':
                        s.sendall('move 0 1\n'.encode())
                    elif cmd[0] == 'left':
                        s.sendall('move -1 0\n'.encode())
                    elif cmd[0] == 'right':
                        s.sendall('move 1 0\n'.encode())
                    else:
                        s.sendall('Invalid command\n'.encode())
                elif len(cmd) == 9 and cmd[0] == 'addmon':
                    name = cmd[1]
                    hello_str = cmd[cmd.index('hello') + 1]
                    hp = cmd[cmd.index('hp') + 1]
                    xx, yy = cmd[cmd.index('coords') + 1:cmd.index('coords') + 3]
                    if xx.isdigit() and yy.isdigit() and 0 <= int(xx) <= 9 and 0 <= int(yy) <= 9:
                        # s.sendall(msg)
                        s.sendall((msg + '\n').encode())
                    else:
                        s.sendall('Invalid arguements\n'.encode())
                elif len(cmd) == 2 and cmd[0] == 'attack':
                    s.sendall((' '.join(cmd) + ' 10\n').encode())
                elif len(cmd) == 4 and cmd[0] == 'attack' and cmd[2] == 'with' and cmd[3] in ['sword', 'spear', 'axe']:
                    if cmd[3] == 'sword':
                        s.sendall((' '.join(cmd[:2]) + ' 10\n').encode())
                    elif cmd[3] == 'spear':
                        s.sendall((' '.join(cmd[:2]) + ' 15\n').encode())
                    elif cmd[3] == 'axe':
                        s.sendall((' '.join(cmd[:2]) + ' 20\n').encode())
                elif len(cmd) == 2 and cmd[0] == 'sayall':
                    s.sendall((msg + '\n').encode())
                elif len(cmd) == 2 and cmd[0] == 'movemonsters' and cmd[1] in ['on', 'off']:
                    s.sendall((msg + '\n').encode())
                elif len(cmd) == 2 and cmd[0] == 'locale' and cmd[1] in ['ru_RU.UTF8', 'en_US.UTF8']:
                    s.sendall((msg + '\n').encode())
                elif len(cmd) >= 1 and cmd[0] in ['up', 'down', 'left', 'right', 'addmon', 'attack', 'sayall', 'movemonsters', 'locale']:
                    s.sendall('Invalid arguements\n'.encode())
                else:
                    s.sendall('Invalid command\n'.encode())
            except KeyboardInterrupt:
                s.sendall('quit\n'.encode())
                break
            except EOFError:
                s.sendall('quit\n'.encode())
                break


if __name__ == '__main__':
    start_client()
